function dx = rhs_controlled(~, x, u, par)
%RHS_CONTROLLED Right-hand side of the controlled fractional model.
%
% u(1)=u1 prevention effort reducing infection
% u(2)=u2 treatment/removal effort for infected prey

S = max(x(1),0);
I = max(x(2),0);
P = max(x(3),0);

u1 = min(1,max(0,u(1)));
u2 = min(1,max(0,u(2)));

den = par.a*S + par.b*I;
if den <= eps
    den = eps;
end

dS = par.r*S/(1 + par.k1*P) * (1 - (S + I)/par.K) ...
     - par.lambda*(1-u1)*S*I ...
     - par.alpha*S*P/den;

dI = par.lambda*(1-u1)*S*I ...
     - par.beta*I*P ...
     - par.mu1*I ...
     - u2*I;

dP = par.theta*par.alpha*S*P/den ...
     + par.theta*par.beta*I*P ...
     - par.mu2*P;

dx = [dS; dI; dP];
end
