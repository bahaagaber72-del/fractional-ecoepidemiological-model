Fractional-Order Ecoepidemiological Predator-Prey Model
=======================================================

This repository contains MATLAB codes for the numerical simulation, bifurcation analysis,
and optimal control of a fractional-order fear-induced ecoepidemiological predator-prey
model governed by Caputo fractional derivatives.

Manuscript:
"Fractional-Order Analysis of a Fear-Induced Ecoepidemiological Predator-Prey Model
with Optimal Control and Bifurcation Dynamics"

Files
-----
main_simulation.m
    Runs the uncontrolled fractional-order model and plots S(t), I(t), P(t).

parameters.m
    Defines the baseline parameter values and initial conditions.

caputo_pc_solver.m
    Predictor-corrector Adams-Bashforth-Moulton solver for Caputo systems.

rhs_uncontrolled.m
    Right-hand side of the uncontrolled ecoepidemiological system.

rhs_controlled.m
    Right-hand side of the controlled model.

optimal_control_fbs.m
    Forward-backward sweep implementation for the fractional optimal control problem.

bifurcation_k1.m
    Numerical bifurcation scan with respect to the fear factor k1.

bifurcation_theta.m
    Numerical bifurcation scan with respect to the conversion efficiency theta.

bifurcation_beta.m
    Numerical bifurcation scan with respect to the hunting efficiency beta.

bifurcation_lambda.m
    Numerical bifurcation scan with respect to the infection rate lambda.

Instructions
------------
1. Place all files in the same folder.
2. Open MATLAB.
3. Set the current folder to this directory.
4. Run:
       main_simulation
   or:
       optimal_control_fbs
   or any bifurcation file.

The codes use only standard MATLAB functions.
