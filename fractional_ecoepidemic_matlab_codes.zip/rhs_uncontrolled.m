function dx = rhs_uncontrolled(~, x, par)
%RHS_UNCONTROLLED Right-hand side of the uncontrolled fractional model.
%
% x(1)=S susceptible prey
% x(2)=I infected prey
% x(3)=P predator

S = max(x(1),0);
I = max(x(2),0);
P = max(x(3),0);

den = par.a*S + par.b*I;
if den <= eps
    den = eps;
end

dS = par.r*S/(1 + par.k1*P) * (1 - (S + I)/par.K) ...
     - par.lambda*S*I ...
     - par.alpha*S*P/den;

dI = par.lambda*S*I ...
     - par.beta*I*P ...
     - par.mu1*I;

dP = par.theta*par.alpha*S*P/den ...
     + par.theta*par.beta*I*P ...
     - par.mu2*P;

dx = [dS; dI; dP];
end
