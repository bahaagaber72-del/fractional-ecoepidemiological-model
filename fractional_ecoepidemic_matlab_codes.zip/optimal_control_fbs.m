clear; clc; close all;

par = parameters();

T = par.T;
N = par.N;
h = T/N;
t = linspace(0,T,N+1);

nu = par.nu;
x0 = par.x0;

u1 = zeros(1,N+1);
u2 = zeros(1,N+1);

maxIter = 100;
tol = 1e-5;
relax = 0.5;

X = zeros(3,N+1);
Psi = zeros(3,N+1);

for iter = 1:maxIter
    u1_old = u1;
    u2_old = u2;

    % Forward state solve using a simple fractional Euler memory discretization
    X(:,1) = x0;
    F = zeros(3,N+1);
    F(:,1) = rhs_controlled(t(1), X(:,1), [u1(1);u2(1)], par);

    for n = 1:N
        sumF = zeros(3,1);
        for j = 1:n
            w = (n-j+1)^nu - (n-j)^nu;
            sumF = sumF + w*F(:,j);
        end
        X(:,n+1) = x0 + h^nu/gamma(nu+1)*sumF;
        X(:,n+1) = max(X(:,n+1),0);
        F(:,n+1) = rhs_controlled(t(n+1), X(:,n+1), [u1(n+1);u2(n+1)], par);
    end

    % Backward adjoint solve by reverse-time finite-difference approximation
    Psi(:,N+1) = [0;0;0];

    for n = N:-1:1
        S = X(1,n+1);
        I = X(2,n+1);
        P = X(3,n+1);
        psi = Psi(:,n+1);

        den = par.a*S + par.b*I;
        if den <= eps
            den = eps;
        end

        % Numerical derivatives of Hamiltonian with respect to states
        gradH = numerical_gradH(S,I,P,u1(n+1),u2(n+1),psi,par);

        Psi(:,n) = Psi(:,n+1) + h*gradH(:);
    end

    % Update controls from projection formulas
    for n = 1:N+1
        S = X(1,n);
        I = X(2,n);
        psi1 = Psi(1,n);
        psi2 = Psi(2,n);

        u1_new = par.lambda*S*I*(psi2 - psi1)/par.B1;
        u2_new = psi2*I/par.B2;

        u1(n) = min(1,max(0,u1_new));
        u2(n) = min(1,max(0,u2_new));
    end

    % Relaxation
    u1 = relax*u1 + (1-relax)*u1_old;
    u2 = relax*u2 + (1-relax)*u2_old;

    err = max([norm(u1-u1_old,inf), norm(u2-u2_old,inf)]);
    fprintf('Iteration %3d: error = %.6e\n',iter,err);

    if err < tol
        break;
    end
end

J = trapz(t, par.A*X(2,:) + 0.5*par.B1*u1.^2 + 0.5*par.B2*u2.^2);
fprintf('Final objective value J = %.8f\n',J);

figure;
plot(t,X(1,:),'LineWidth',1.8); hold on;
plot(t,X(2,:),'LineWidth',1.8);
plot(t,X(3,:),'LineWidth',1.8);
xlabel('Time');
ylabel('State variables');
legend('S(t)','I(t)','P(t)','Location','best');
title('Controlled state variables');
grid on;

figure;
plot(t,u1,'LineWidth',1.8); hold on;
plot(t,u2,'LineWidth',1.8);
xlabel('Time');
ylabel('Control level');
legend('u_1(t)','u_2(t)','Location','best');
title('Optimal controls');
grid on;

function gradH = numerical_gradH(S,I,P,u1,u2,psi,par)
    x = [S;I;P];
    eps0 = 1e-6;
    gradH = zeros(3,1);

    for k = 1:3
        xp = x; xm = x;
        xp(k) = xp(k) + eps0;
        xm(k) = max(xm(k) - eps0,0);

        Hp = Hamiltonian(xp,u1,u2,psi,par);
        Hm = Hamiltonian(xm,u1,u2,psi,par);

        gradH(k) = (Hp - Hm)/(xp(k)-xm(k));
    end
end

function H = Hamiltonian(x,u1,u2,psi,par)
    f = rhs_controlled(0,x,[u1;u2],par);
    H = par.A*x(2) + 0.5*par.B1*u1^2 + 0.5*par.B2*u2^2 + psi(:)'*f(:);
end
