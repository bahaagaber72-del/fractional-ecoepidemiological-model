clear; clc; close all;

par = parameters();
values = linspace(0.05,1.0,80);

Ttrans = round(0.6*par.N);
peaks_I = [];
vals_I = [];

for q = 1:length(values)
    par.theta = values(q);

    [t, X] = caputo_pc_solver(@rhs_uncontrolled, [0 par.T], par.x0, par.nu, par.N, par);

    I = X(2,Ttrans:end);

    % local maxima of infected prey
    for j = 2:length(I)-1
        if I(j) > I(j-1) && I(j) > I(j+1)
            peaks_I(end+1) = I(j); %#ok<SAGROW>
            vals_I(end+1) = values(q); %#ok<SAGROW>
        end
    end

    if isempty(peaks_I) || vals_I(end) ~= values(q)
        peaks_I(end+1) = I(end); %#ok<SAGROW>
        vals_I(end+1) = values(q); %#ok<SAGROW>
    end
end

figure;
plot(vals_I, peaks_I, '.', 'MarkerSize', 8);
xlabel('conversion efficiency \theta');
ylabel('Local maxima of infected prey I(t)');
title('Bifurcation diagram with respect to conversion efficiency \theta');
grid on;
