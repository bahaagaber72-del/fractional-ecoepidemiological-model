function par = parameters()
%PARAMETERS Baseline parameter values for the fractional ecoepidemiological model.

par.r      = 1.2;     % intrinsic prey growth rate
par.K      = 50;      % carrying capacity
par.k1     = 0.8;     % fear factor
par.lambda = 0.025;   % disease transmission rate
par.alpha  = 0.45;    % predation rate on susceptible prey
par.beta   = 0.30;    % predation rate on infected prey
par.a      = 1.0;     % half-saturation constant for susceptible prey
par.b      = 1.0;     % half-saturation constant for infected prey
par.theta  = 0.40;    % conversion efficiency
par.mu1    = 0.35;    % infected prey mortality/removal rate
par.mu2    = 0.20;    % predator mortality rate

% Control and cost parameters
par.A  = 1.0;
par.B1 = 20.0;
par.B2 = 20.0;

% Initial conditions
par.x0 = [30; 5; 4];

% Time parameters
par.T  = 100;
par.N  = 1000;

% Fractional order
par.nu = 0.90;
end
