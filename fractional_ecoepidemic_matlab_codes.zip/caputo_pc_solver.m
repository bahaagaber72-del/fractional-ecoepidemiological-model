function [t, X] = caputo_pc_solver(fun, tspan, x0, nu, N, par)
%CAPUTO_PC_SOLVER Predictor-corrector solver for Caputo fractional systems.
%
% Solves:
%       C D_t^nu x(t) = f(t,x(t)),    0 < nu <= 1.
%
% Uses the fractional Adams-Bashforth-Moulton predictor-corrector scheme.

t0 = tspan(1);
T  = tspan(2);
h  = (T - t0)/N;
t  = linspace(t0,T,N+1);

m = length(x0);
X = zeros(m,N+1);
F = zeros(m,N+1);

X(:,1) = x0(:);
F(:,1) = fun(t(1), X(:,1), par);

for n = 1:N
    % Predictor
    xp = x0(:);
    for j = 0:n-1
        bj = (n-j)^nu - (n-j-1)^nu;
        xp = xp + h^nu/gamma(nu+1) * bj * F(:,j+1);
    end

    fp = fun(t(n+1), xp, par);

    % Corrector
    xc = x0(:) + h^nu/gamma(nu+2) * fp;
    for j = 0:n-1
        if j == 0
            aj = n^(nu+1) - (n-nu)*(n+1)^nu;
        else
            aj = (n-j+2)^(nu+1) + (n-j)^(nu+1) - 2*(n-j+1)^(nu+1);
        end
        xc = xc + h^nu/gamma(nu+2) * aj * F(:,j+1);
    end

    X(:,n+1) = max(real(xc),0);
    F(:,n+1) = fun(t(n+1), X(:,n+1), par);
end
end
