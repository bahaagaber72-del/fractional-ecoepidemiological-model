clear; clc; close all;

par = parameters();

[t, X] = caputo_pc_solver(@rhs_uncontrolled, [0 par.T], par.x0, par.nu, par.N, par);

S = X(1,:);
I = X(2,:);
P = X(3,:);

figure;
plot(t,S,'LineWidth',1.8); hold on;
plot(t,I,'LineWidth',1.8);
plot(t,P,'LineWidth',1.8);
xlabel('Time');
ylabel('Population density');
legend('Susceptible prey S(t)','Infected prey I(t)','Predator P(t)','Location','best');
title(['Fractional ecoepidemiological model, \nu = ',num2str(par.nu)]);
grid on;

figure;
plot3(S,I,P,'LineWidth',1.5);
xlabel('S(t)');
ylabel('I(t)');
zlabel('P(t)');
title('Phase portrait');
grid on;
